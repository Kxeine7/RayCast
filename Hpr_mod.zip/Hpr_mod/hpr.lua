SMODS.Atlas{
    key = 'hpr_consumeables',
    path = 'hpr_consumeables.png',
    px = 71,
    py = 95
}

SMODS.DrawStep {
    key = 'hpr_card_shader',
    order = 21,
    func = function(self, layer)
        if self.area and self.config.center.mod and self.config.center.mod.id == "hpr" then
            self.children.center:draw_shader('booster', nil, self.ARGS.send_to_shader)
        end
    end,
    --conditions = { vortex = false, facing = 'front' },
}

SMODS.ConsumableType {
    key = "hpr_card",
    primary_colour = HEX("79005C"),
    secondary_colour = HEX("A7154C"),
    loc_txt = {
        name = "HPR",
        collection = "HPR Cards"
    },
    collection_rows = {6, 6},
    shop_rate = 0,
    default = "c_hpr_placeholder",
}

SMODS.UndiscoveredSprite {
    key = "hpr_card",
    atlas = "hpr_consumeables",
    pos = {x = 6, y = 5} 
}

SMODS.Consumable{
    key = "c_hpr_placeholder",
    set = "hpr_card",
    atlas = "hpr_consumeables",
    pos = {x = 0, y = 4},
    soul_pos = {x = 1, y = 4},
    loc_txt = {
        name = "Placeholder",
        text = {
            "This card holds the place",
        }
    },
    config = { context =
        {
            value = 1
        }
    },
    discovered = false,
    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.context.number_cards}}
    end,
    can_use = function(self, card) --Fix this condition???

    end,
    use = function(self, card, area, copier)

    end
}

SMODS.Consumable{
    key = "c_hpr_placeholder2",
    set = "hpr_card",
    atlas = "hpr_consumeables",
    pos = {x = 0, y = 4},
    soul_pos = {x = 1, y = 4},
    loc_txt = {
        name = "Placeholder 2",
        text = {
            "This card holds the place",
        }
    },
    config = { context =
        {
            value = 1
        }
    },
    discovered = false,
    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.context.number_cards}}
    end,
    can_use = function(self, card) --Fix this condition???

    end,
    use = function(self, card, area, copier)

    end
}